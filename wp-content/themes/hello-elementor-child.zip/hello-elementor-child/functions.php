<?php
/**
 * Hello Elementor Child Theme functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package hello-elementor-child
 */

add_action('wp_enqueue_scripts', 'hello_elementor_parent_theme_enqueue_styles');

/**
 * Enqueue scripts and styles.
 */
function hello_elementor_parent_theme_enqueue_styles()
{
	wp_enqueue_style('hello-elementor-style', get_template_directory_uri() . '/style.css');
	wp_enqueue_style('my-hello-elementor-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		['hello-elementor-style']
	);
}


// Start : Function to delete all post meta when a post is deleted
// Add an action hook to delete post meta when a post is deleted
add_action('before_delete_post', 'delete_all_post_meta');
function delete_all_post_meta($post_id)
{
	// Get all post meta keys for the given post
	$meta_keys = get_post_custom_keys($post_id);

	// If there are meta keys, delete them
	if ($meta_keys) {
		foreach ($meta_keys as $meta_key) {
			delete_post_meta($post_id, $meta_key);
		}
	}
}

// END : Function to delete all post meta when a post is deleted


// START : Function to display dealer_id set or not
function display_dealer_id_notice()
{
	$dealer_id = get_option('dealer_id');

	if ($dealer_id) {
		echo '<div class="notice notice-success">
            <p>Dealer ID: ' . esc_html($dealer_id) .  '</p>
        </div>';
	} else {
		echo '<div class="notice notice-error">
            <p style="color: red;">Dealer ID not set yet.</p>
        </div>';
	}
}

add_action('admin_notices', 'display_dealer_id_notice');
// END : Function to display dealer_id set or not


// START : Delete all linked images for deleted post  (not working yet)

// Hook into the post deletion process
// Hook into the post deletion process
add_action('before_delete_post', 'delete_linked_media');

function delete_linked_media($post_id)
{
	$attachments = get_attached_media('', $post_id);
	foreach ($attachments as $attachment) {
		wp_delete_attachment($attachment->ID, true);
	}
}

// END : Delete all linked images for deleted post

// START : Add a custom field to pages named 'pwa_page_id'

function add_pwa_page_id_custom_field()
{
	add_meta_box(
		'pwa_page_id_custom_field',
		'PWA Page ID',
		'render_pwa_page_id_custom_field',
		'page', // Add custom field to pages
		'normal',
		'default'
	);
}

// Render the custom field
function render_pwa_page_id_custom_field($post)
{
	// Get the current value of the custom field, if it exists
	$pwa_page_id = get_post_meta($post->ID, 'pwa_page_id', true);
	?>
	<label for="pwa_page_id">PWA Page ID:</label>
	<input type="text" id="pwa_page_id" name="pwa_page_id" value="<?php echo esc_attr($pwa_page_id); ?>"/>
	<?php
}

// Save the custom field value when the page is updated or published
function save_pwa_page_id_custom_field($post_id)
{
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

	if (isset($_POST['pwa_page_id'])) {
		$pwa_page_id = sanitize_text_field($_POST['pwa_page_id']);
		update_post_meta($post_id, 'pwa_page_id', $pwa_page_id);
	}
}

// Hook the custom field functions into WordPress
add_action('add_meta_boxes', 'add_pwa_page_id_custom_field');
add_action('save_post', 'save_pwa_page_id_custom_field');

// END : Add a custom field to pages named 'pwa_page_id'

// START : add id vehicle to url
function custom_vehicles_rewrite_rules() {
	add_rewrite_rule(
		'^vehicles/([0-9]+)/([^/]+)/?$',
		'index.php?post_type=vehicles&name=$matches[2]&id=$matches[1]',
		'top'
	);
}
add_action('init', 'custom_vehicles_rewrite_rules');

function custom_vehicles_post_type_link($permalink, $post) {
	if ($post->post_type == 'vehicles') {
		$id = get_post_meta($post->ID, 'id', true);
		if (!empty($id)) {
			$permalink = home_url("/vehicles/{$id}/{$post->post_name}/");
		}
	}
	return $permalink;
}
add_filter('post_type_link', 'custom_vehicles_post_type_link', 10, 2);

// END : add id vehicle to url


// Start : Redis
function loadRedisAndDotEnv(){
	require_once ABSPATH . 'vendor/autoload.php';
	$dotenv = Dotenv\Dotenv::createImmutable(ABSPATH);
	$dotenv->load();
	//Redis Config
	$redisConfig =[
		'scheme' => "tcp",
		'host' => getenv('WP_REDIS_HOST'),
		'port' => getenv('WP_REDIS_PORT'),
		'password' => getenv('WP_REDIS_PASSWORD'),
		'database' => 1,
		'cluster' => 'redis',
	];
	global $redis;
	global $use_redis;
	try {
		$redis = new Predis\Client($redisConfig);
		$redis->connect();
		$use_redis = true;
	} catch (Predis\Connection\ConnectionException $e) {
		$use_redis = false;
	}
}

add_action('init', 'loadRedisAndDotEnv');
// Start : Redis
